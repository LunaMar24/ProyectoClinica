﻿Public Class frmGenerarConsulta

End Class